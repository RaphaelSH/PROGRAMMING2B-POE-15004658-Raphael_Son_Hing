﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PROGRAMMING2B_POE_15004658_Raphael_Son_Hing.Models
{
    public class Class
    {
        public void Login()
        {
      

        }
    }


}
