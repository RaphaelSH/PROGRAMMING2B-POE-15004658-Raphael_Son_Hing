using System;

namespace PROGRAMMING2B_POE_15004658_Raphael_Son_Hing.Models
{
    public class ErrorViewModel
    {
        public string RequestId { get; set; }

        public bool ShowRequestId => !string.IsNullOrEmpty(RequestId);


    }


}
