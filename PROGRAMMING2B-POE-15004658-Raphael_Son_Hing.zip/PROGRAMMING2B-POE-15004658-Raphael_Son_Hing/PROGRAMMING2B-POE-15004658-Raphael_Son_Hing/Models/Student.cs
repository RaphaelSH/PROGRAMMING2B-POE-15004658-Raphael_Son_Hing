﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PROGRAMMING2B_POE_15004658_Raphael_Son_Hing.Models
{
    public class Student
    {
        public string UserName { get; set; }
        public string Password { get; set; }
        public string CurrentDate { get; set; }
        public int WeeksLeft { get; set; }
        public string ClassName { get; set; }
        public string ClassCode { get; set; }
        public int Credits { get; set; }
        public int HoursPerClass { get; set; }
        public int Hours1 { get; set; }
        public int Hours2 { get; set; }
        public int Hours3 { get; set; }
        public int Hours4 { get; set; }
        public string Date1 { get; set; }
        public string Date2 { get; set; }
        public string Date3 { get; set; }
        public string Date4 { get; set; }
    }
}
