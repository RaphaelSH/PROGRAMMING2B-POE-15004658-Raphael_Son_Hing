﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using PROGRAMMING2B_POE_15004658_Raphael_Son_Hing.Models;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;

namespace PROGRAMMING2B_POE_15004658_Raphael_Son_Hing.Controllers
{
    public class HomeController : Controller
    {
        private List<Student> list = new List<Student>();

        private List<Student> getAllStudents()
        {
            if (list.Count == 0)
            {
                list.Add(new Student()
                {
                    UserName = "Alpha",
                    Password = "Alpha",
                    CurrentDate = "31 May",
                    WeeksLeft = 5,
                    ClassName = "Math",
                    ClassCode = "MAT041",
                    Credits = 8,
                    HoursPerClass = 4,
                    Hours1 = 1,
                    Hours2 = 2,
                    Hours3 = 3,
                    Hours4 = 4,
                    Date1 = "2 June",
                    Date2 = "3 August",
                    Date3 = "4 September",
                    Date4 = "5 October"
                });
                list.Add(new Student()
                {
                    UserName = "Bravo",
                    Password = "Bravo",
                    CurrentDate = "31 May",
                    WeeksLeft = 5,
                    ClassName = "English",
                    ClassCode = "ENG543",
                    Credits = 8,
                    HoursPerClass = 4,
                    Hours1 = 1,
                    Hours2 = 2,
                    Hours3 = 3,
                    Hours4 = 4,
                    Date1 = "2 August",
                    Date2 = "3 October",
                    Date3 = "4 November",
                    Date4 = "5 December"
                });
                list.Add(new Student()
                {
                    UserName = "Charlie",
                    Password = "Charlie",
                    CurrentDate = "31 May",
                    WeeksLeft = 6,
                    ClassName = "History",
                    ClassCode = "HIS785",
                    Credits = 8,
                    HoursPerClass = 4,
                    Hours1 = 1,
                    Hours2 = 2,
                    Hours3 = 3,
                    Hours4 = 4,
                    Date1 = "22 June",
                    Date2 = "23 August",
                    Date3 = "24 September",
                    Date4 = "25 October"
                });
                list.Add(new Student()
                {
                    UserName = "Delta",
                    Password = "Delta",
                    CurrentDate = "31 May",
                    WeeksLeft = 7,
                    ClassName = "Equestrian",
                    ClassCode = "Math",
                    Credits = 8,
                    HoursPerClass = 4,
                    Hours1 = 1,
                    Hours2 = 2,
                    Hours3 = 3,
                    Hours4 = 4,
                    Date1 = "6 June",
                    Date2 = "8 August",
                    Date3 = "14 September",
                    Date4 = "15 October"
                });
            }
            return list;
        }

        public Student getStudent(string UserName)
        {
            var answer = getAllStudents().Where(p => p.UserName == UserName).First();
            return answer;
        }


        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            return View();

        }

        public IActionResult Privacy()
        {
            return View();
        }
        public IActionResult Register()
        {
            return View();
        }
        public IActionResult dead_end()
        {
            return View();
        }
        public IActionResult template()
        {
            return View();
        }

        public IActionResult Schedule()
        {
            return View();
        }
        public IActionResult Help()
        {
            return View();
        }
        public IActionResult About()
        {
            return View();
        }
        public IActionResult Graph()
        {
            return View();
        }
        public IActionResult Logout()
        {
            return View();
        }
        public IActionResult Users()
        {
            return View(getAllStudents());
        }


        [Route("Home/Student/{name}")]
        public IActionResult Student(string name)
        {
            return View(getStudent(name));
        }
        //Testing sessions
        const string SessionName = "_Name";
        const string SessionAge = "_Age";
        public IActionResult IndexTest()
        {
            HttpContext.Session.SetString(SessionName, "Jarvik");
            HttpContext.Session.SetInt32(SessionAge, 24);
            return View();
        }

        public IActionResult AboutTest()
        {
            ViewBag.Name = HttpContext.Session.GetString(SessionName);
            ViewBag.Age = HttpContext.Session.GetInt32(SessionAge);
            ViewData["Message"] = "Asp.Net Core !!!.";

            return View();
        }

        public IActionResult Contact()
        {
            ViewData["Message"] = "Your contact page.";

            return View();
        }

        public IActionResult ErrorTest()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }


        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
